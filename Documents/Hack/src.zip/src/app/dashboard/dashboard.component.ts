import { Component, OnInit } from '@angular/core';
// import { Chart } from 'angular-highcharts';
// import * as Highcharts from 'highcharts/modules/stock.src';
// import CanvasJS from 'canvasjs';
declare var CanvasJS: any;
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor() { }
  chart: any;
  peopleChart: any;
  barChart: any;
  ngOnInit() {
    // this.getChart();
    // this.getPeopleChart();



  }
  onClick() {
  }
  // getChart() {
  //   this.chart = new Chart({


  //     chart: {
  //       type: 'bubble',
  //       plotBorderWidth: 1,
  //       zoomType: 'xy'
  //     },

  //     legend: {
  //       enabled: true,
  //       labelFormatter: function () {
  //         return this.name ;
  //     }
  //     },
  //     xAxis: {
  //       visible: false
  //     },

  //     yAxis: {
  //       visible: false
  //     },
  //     title: {
  //       text: 'Title'
  //     },

  //     credits: {
  //       enabled: false
  //     },


  //     tooltip: {
  //       useHTML: true,
  //       headerFormat: '<table>',
  //       pointFormat: '<tr><th colspan="2"><span>{point.name}</span></th></tr>' +
  //         '<td></tr>',
  //       footerFormat: '</table>',
  //       followPointer: true,
  //       style: {
  //         fontSize: '16px',
  //       }

  //     },

  //     plotOptions: {
  //       series: {

  //         cursor: 'pointer',
  //         events: {
  //           click: function (event) {
  //             console.log("a", event.point.name);
  //           }
  //         },
  //         dataLabels: {
  //           enabled: true,
  //           format: ''

  //         },
  //         animation: true

  //       },
  //       bubble: {
  //         minSize: 40,
  //         maxSize: 40
  //       }

  //     },

  //     series: [{
  //       name: 'Highly Affected',
  //       data: [
  //         { x: 50, y: 60, z: 120, name: "Thiruvalla" },
  //         { x: 62.5, y: 52.5, z: 120, name: "Mavelikkara" },
  //         { x: 77.5, y: 75.5, z: 120, name: "Kodungallur" },
  //         { x: 80, y: 70, z: 120, name: "Thissur"},
  //         { x: 65, y: 65, z: 120, name: "Kothamangalam" },
  //         { x: 60, y: 80, z: 120, name: "Alappuzha" }
  //       ],
  //       color: '#FF0000'

  //     },{
  //       name:'Moderate Affected',
  //   data:[
  //     { x: 52.5, y: 80, z: 120, name: "Chengannur"},
  //     { x: 55, y: 70, z: 120, name: "Mallapally"},
  //     { x: 70, y: 80, z: 120, name: "Muvattupuzha"},
  //     { x: 72.5, y: 70, z: 120, name: "Kunnathunad" }
  //   ],
  //   color:"#FFF263"
  // },
  // {
  //   name:'Less Affected',

  //   data:[
  //     { x: 67.5, y: 57.5, z: 120, name: "Aluva"},
  //     { x: 75.5, y: 60, z: 120, name: "Wadakkancheri"},
  //     { x: 75, y: 50, z: 120, name: "Mukundapuram"},
  //     { x: 57.5, y: 65, z: 120, name: "Cherthala"}

  //   ]
  // }
  // ]

  //   });
  // }

  // getPeopleChart() {
  //   this.peopleChart = new Chart({
  //     chart: {
  //       type: 'column'
  //     },
  //     title: {
  //       text: 'Title'
  //     },
  //     credits: {
  //       enabled: false
  //     },
  //     xAxis: {
  //       categories: ['mare hue', 'ghayal', 'jinda']
  //     },
  //     yAxis: {
  //       min: 0,
  //       title: {
  //         text: 'Logo Ki ginti'
  //       },
  //       stackLabels: {
  //         enabled: false,

  //       }
  //     },
  //     tooltip: {
  //       headerFormat: '<b></b><br/>',
  //       pointFormat: '{point.stackTotal}'
  //     },
  //     plotOptions: {
  //       column: {
  //         stacking: 'normal',
  //         dataLabels: {
  //           enabled: false,
  //           color: (Highcharts.theme && Highcharts.theme.dataLabelsColor)
  //         }
  //       }
  //     },
  //     series: [{
  //       name: 'mare hue',
  //       data: [500, 0, 0]
  //     }, {
  //       name: 'ghayal',
  //       data: [0, 280, 0]
  //     }, {
  //       name: 'jinda',
  //       data: [0, 0, 400]
  //     }]
  //   });
  // }
}




import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-indoor-view',
  templateUrl: './indoor-view.component.html',
  styleUrls: ['./indoor-view.component.css']
})
export class IndoorViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

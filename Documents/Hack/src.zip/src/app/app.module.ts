import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AgmCoreModule } from '@agm/core';
import { AppComponent } from './app.component';
import { StateMapComponent } from './state-map/state-map.component';
import { RouterModule, Routes} from '@angular/router';
import { MatCardModule, MatListModule } from '@angular/material';
import { AgmJsMarkerClustererModule } from '@agm/js-marker-clusterer';
import { IndoorViewComponent } from './indoor-view/indoor-view.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DonationComponent } from './donation/donation.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatDividerModule} from '@angular/material/divider';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatSelectModule} from '@angular/material/select';
import {MatInputModule} from '@angular/material';
import {MatButtonModule} from '@angular/material/button';
import {ReactiveFormsModule, FormsModule, FormControl} from '@angular/forms';


const appRoutes: Routes = [
  { path: 'mapView', component: StateMapComponent },
  { path: 'indoorView', component: IndoorViewComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'donate', component: DonationComponent },
  { path: '**', redirectTo: 'mapView' },
  { path: '', redirectTo: 'mapView', pathMatch: 'full' }
];

@NgModule({
  declarations: [
    AppComponent,
    StateMapComponent,
    IndoorViewComponent,
    DashboardComponent,
    DonationComponent
  ],
  imports: [
    BrowserModule,
    AgmCoreModule,
    RouterModule.forRoot(appRoutes),
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyD9N09q8rpaHvhI2t53HxMtD8zGkvUCRk8'
    }),
    AgmJsMarkerClustererModule,
    MatCardModule,
    MatListModule,
    MatGridListModule,
    BrowserAnimationsModule,
    MatDividerModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatButtonModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
